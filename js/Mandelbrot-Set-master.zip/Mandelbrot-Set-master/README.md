## This is a mandelbrot-set effect completed in p5.js

Made using the video tutorial here: https://www.youtube.com/watch?v=6z7GQewK-Ks

The sketch code is here: https://github.com/lprescott/Mandelbrot-Set/blob/master/js/mandelbrot.js

## Resources:
1. [p5.js](https://p5js.org/)
